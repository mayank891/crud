from django.shortcuts import render,redirect
from myapp.forms import EmployeeForm
from myapp.models import Employee
def save(request):
    if request.method=='POST':
        frm=EmployeeForm(request.POST)
        try:
            if(frm.is_valid()):
                frm.save()
                return redirect("/show")
        except:
            pass
    else:
        frm=EmployeeForm()
    return render(request,'index.html',{'form':frm})
def showrecord(request):
    Employees=Employee.objects.all()
    return render (request,'show.html',{'Employees':Employees})
def remove(request,id):
    empl=Employee.objects.get(id=id)
    empl.delete()
    return redirect("/show")
def edit(request,id):
    empl=Employee.objects.get(id=id)
    return render(request,"edit.html",{'employee':empl})
def update(request,id):
    empl=Employee.objects.get(id=id)
    form=EmployeeForm(request.POST,instance=empl)
    if form.is_valid():
        form.save()
        return redirect("/show")
    return render(request,'edit.html', {'employee':empl})
    