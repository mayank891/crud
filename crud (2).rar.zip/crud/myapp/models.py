from django.db import models
class Employee(models.Model):
    empno=models.CharField(max_length=20)
    ename=models.CharField(max_length=30)
    email=models.EmailField()
    address=models.CharField(max_length=100)
    class Meta:
        db_table="Employee"
