
from django.contrib import admin
from django.urls import path
from myapp.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('emp',save),
    path('show',showrecord),
    path('delete/<int:id>',remove),
    path('edit/<int:id>',edit),
    path('update/<int:id>',update),
]
